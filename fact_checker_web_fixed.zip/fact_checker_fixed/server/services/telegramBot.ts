import axios from "axios";
import { getDb } from "../db";
import { getFactCheckReports, getFactCheckReportStats } from "../db";
import { factCheckReports, telegramUsers, telegramNotifications } from "../../drizzle/schema";
import { eq, and, isNull } from "drizzle-orm";

const TELEGRAM_API_URL = "https://api.telegram.org/bot";
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

if (!BOT_TOKEN) {
  console.warn("[TelegramBot] TELEGRAM_BOT_TOKEN not set. Bot functionality disabled.");
}

/**
 * Send a message to a Telegram user
 */
export async function sendTelegramMessage(
  chatId: string | number,
  text: string,
  options?: {
    parseMode?: "HTML" | "Markdown" | "MarkdownV2";
    replyMarkup?: any;
  }
): Promise<boolean> {
  if (!BOT_TOKEN) {
    console.warn("[TelegramBot] Cannot send message: BOT_TOKEN not configured");
    return false;
  }

  try {
    const response = await axios.post(`${TELEGRAM_API_URL}${BOT_TOKEN}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: options?.parseMode || "HTML",
      reply_markup: options?.replyMarkup,
    });

    return response.status === 200;
  } catch (error) {
    console.error("[TelegramBot] Failed to send message:", error);
    return false;
  }
}

/**
 * Send a formatted report summary to Telegram
 */
export async function sendReportNotification(
  chatId: string | number,
  reportId: string | number,
  title: string,
  mainClaim: string,
  source: string
): Promise<boolean> {
  const message = `
<b>📰 Novo Relatório de Fact-Checking</b>

<b>Título:</b> ${escapeHtml(title)}

<b>Alegação Principal:</b> ${escapeHtml(mainClaim)}

<b>Fonte:</b> ${escapeHtml(source)}

<b>ID do Relatório:</b> <code>${reportId}</code>

Visite o dashboard para mais detalhes.
  `.trim();

  const keyboard = {
    inline_keyboard: [
      [
        {
          text: "Ver Relatório",
          url: `${process.env.VITE_FRONTEND_URL || "http://localhost:3000"}/reports/${reportId}`,
        },
      ],
    ],
  };

  return sendTelegramMessage(chatId, message, {
    parseMode: "HTML",
    replyMarkup: keyboard,
  });
}

/**
 * Send statistics to Telegram
 */
export async function sendStatsMessage(chatId: string | number): Promise<boolean> {
  const stats = await getFactCheckReportStats();

  const message = `
<b>📊 Estatísticas de Fact-Checking</b>

<b>Total de Relatórios:</b> ${stats.total}
<b>Verificados:</b> ${stats.verified}
<b>Não Verificados:</b> ${stats.unverified}

<b>Por Fonte:</b>
${Object.entries(stats.bySource)
  .map(([source, count]) => `• ${escapeHtml(source)}: ${count}`)
  .join("\n")}
  `.trim();

  return sendTelegramMessage(chatId, message, { parseMode: "HTML" });
}

/**
 * Send latest reports to Telegram
 */
export async function sendLatestReportsMessage(chatId: string | number, limit: number = 5): Promise<boolean> {
  const reports = await getFactCheckReports(limit, 0);

  if (reports.length === 0) {
    return sendTelegramMessage(chatId, "Nenhum relatório disponível no momento.", {
      parseMode: "HTML",
    });
  }

  const reportsList = reports
    .map(
      (r, idx) =>
        `${idx + 1}. <b>${escapeHtml(r.title.substring(0, 50))}</b>\n   Fonte: ${escapeHtml(r.source)}\n   Status: ${r.verificationStatus}`
    )
    .join("\n\n");

  const message = `
<b>📰 Últimos Relatórios</b>

${reportsList}

Visite o dashboard para mais detalhes.
  `.trim();

  return sendTelegramMessage(chatId, message, { parseMode: "HTML" });
}

/**
 * Send search results to Telegram
 */
export async function sendSearchResultsMessage(
  chatId: string | number,
  query: string,
  results: any[]
): Promise<boolean> {
  if (results.length === 0) {
    return sendTelegramMessage(chatId, `Nenhum resultado encontrado para "${escapeHtml(query)}"`, {
      parseMode: "HTML",
    });
  }

  const resultsList = results
    .slice(0, 5)
    .map(
      (r, idx) =>
        `${idx + 1}. <b>${escapeHtml(r.title.substring(0, 50))}</b>\n   Fonte: ${escapeHtml(r.source)}`
    )
    .join("\n\n");

  const message = `
<b>🔍 Resultados da Busca</b>

Busca por: "${escapeHtml(query)}"

${resultsList}

${results.length > 5 ? `\n... e mais ${results.length - 5} resultados. Visite o dashboard para ver todos.` : ""}
  `.trim();

  return sendTelegramMessage(chatId, message, { parseMode: "HTML" });
}

/**
 * Broadcast a message to all subscribed users
 */
export async function broadcastMessage(text: string, userIds: string[]): Promise<number> {
  let successCount = 0;

  for (const userId of userIds) {
    const success = await sendTelegramMessage(userId, text, { parseMode: "HTML" });
    if (success) successCount++;
  }

  return successCount;
}

/**
 * Escape HTML special characters for Telegram
 */
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Send notifications for newly verified reports
 * Uses telegramNotifications table to avoid duplicate notifications
 */
export async function sendNotificationsForNewReports(): Promise<number> {
  try {
    const db = await getDb();
    if (!db) {
      console.warn("[TelegramBot] Database not available");
      return 0;
    }

    // Get all subscribed users
    const users = await db
      .select()
      .from(telegramUsers)
      .where(eq(telegramUsers.isSubscribed, true as any));

    if (users.length === 0) return 0;

    // Get recently verified reports
    const recentReports = await db
      .select()
      .from(factCheckReports)
      .where(eq(factCheckReports.isVerified, true as any))
      .limit(10);

    let notificationCount = 0;

    for (const report of recentReports) {
      for (const user of users) {
        // Check if notification already sent for this user+report combination
        const existing = await db
          .select()
          .from(telegramNotifications)
          .where(
            and(
              eq(telegramNotifications.telegramUserId, user.id),
              eq(telegramNotifications.reportId, report.id)
            )
          )
          .limit(1);

        if (existing.length > 0) continue; // Already notified

        // Insert pending notification record
        await db.insert(telegramNotifications).values({
          telegramUserId: user.id,
          reportId: report.id,
          status: "pending",
        });

        const success = await sendReportNotification(
          user.telegramId,
          report.id,
          report.title,
          report.mainClaim,
          report.source
        );

        // Update status
        await db
          .update(telegramNotifications)
          .set({
            status: success ? "sent" : "failed",
            sentAt: success ? new Date() : undefined,
          })
          .where(
            and(
              eq(telegramNotifications.telegramUserId, user.id),
              eq(telegramNotifications.reportId, report.id)
            )
          );

        if (success) notificationCount++;
      }
    }

    console.log(`[TelegramBot] Sent ${notificationCount} notifications`);
    return notificationCount;
  } catch (error) {
    console.error("[TelegramBot] Error sending notifications:", error);
    return 0;
  }
}

/**
 * Handle Telegram webhook updates
 */
export async function handleTelegramUpdate(update: any): Promise<void> {
  try {
    if (update.message) {
      const message = update.message;
      const chatId = message.chat.id;
      const text = message.text || "";
      const user = message.from;

      // Handle commands
      if (text.startsWith("/start")) {
        await sendTelegramMessage(
          chatId,
          `Bem-vindo ao Fact Checker Bot! 🤖\n\nComandos disponíveis:\n/latest - Últimos relatórios\n/stats - Estatísticas\n/search - Buscar relatórios\n/subscribe - Ativar notificações\n/unsubscribe - Desativar notificações`,
          { parseMode: "HTML" }
        );
      } else if (text.startsWith("/latest")) {
        await sendLatestReportsMessage(chatId);
      } else if (text.startsWith("/stats")) {
        await sendStatsMessage(chatId);
      } else if (text.startsWith("/subscribe")) {
        // Upsert user and set isSubscribed = true
        const { createOrUpdateTelegramUser } = await import("../db");
        await createOrUpdateTelegramUser({
          telegramId: String(chatId),
          firstName: user?.first_name,
          lastName: user?.last_name,
          username: user?.username,
          isSubscribed: true,
        });
        await sendTelegramMessage(chatId, "✅ Você foi inscrito nas notificações!", {
          parseMode: "HTML",
        });
      } else if (text.startsWith("/unsubscribe")) {
        // Update existing user to isSubscribed = false
        const db = await (await import("../db")).getDb();
        if (db) {
          const { telegramUsers } = await import("../../drizzle/schema");
          await db
            .update(telegramUsers)
            .set({ isSubscribed: false })
            .where(eq(telegramUsers.telegramId, String(chatId)));
        }
        await sendTelegramMessage(chatId, "❌ Você foi desinscrito das notificações.", {
          parseMode: "HTML",
        });
      }
    }
  } catch (error) {
    console.error("[TelegramBot] Error handling update:", error);
  }
}
